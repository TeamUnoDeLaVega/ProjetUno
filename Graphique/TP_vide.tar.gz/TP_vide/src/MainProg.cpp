#include <iostream>

int main() {
    std::cout << "Audi, vive, tace si vis vivere in pace." << std::endl;
    return 0;
}

