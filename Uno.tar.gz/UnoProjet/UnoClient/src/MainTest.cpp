#define BOOST_TEST_MODULE MesTestsUnitaires
#include <boost/test/included/unit_test.hpp>
//#include "FonctionTest.hpp"
// ré-enregistrer ce fichier pour forcer la recompilation des tests unitaires



