Pour lancer le serveur: 
_ allez dans le dossier UnoServeur sur une console
_ compilez en lançant la commande « make » 
_ lancez le serveur en tapant: « ./bin/MainProg.cpp ».

Une fois le serveur lancé, laissez le tourné dans une console et:
_ ouvrez un autre terminal pour aller dans le dossier UnoClient
_ compilez en lançant la commande « make »
_ lancez le jeu en tapant: « ./bin/MainProg.cpp ».
_ Une fenêtre de login d’affiche
_ Entrez votre pseudo (uniquement les lettres)
_cliquez sur la fenêtre, sur la touche Entrée ou Tab pour taper l’adresse IP sur serveur
_ Entrez l’adresse IP locale du serveur et appuyez sur la touche Entrée

Le jeu:
_ Le serveur se lance quand les 4 joueurs sont connectés
_ Quand le jeton est face a vous, vous pouvez cliquez sur les cartes, sinon vous devez attendre
_ Quand vous choisissez un joker ou une carte +4, un curseur d’affiche, cliquez sur la couleur que vous voulez

