
#ifndef JEU_HPP_
#define JEU_HPP_
#include "Carte.hpp"
#include "Joueur.hpp"
#include <vector>
#include "JeuSrv.hpp"


class Jeu {
public:
  std::vector <Carte> _paquet;
  int _joueurCourant;
  int _sens;
  Carte _carteCourante;
  std::vector <Carte> _historique;
  Jeu();
  std::vector <Joueur> _players; 
  
  
  void creerJoueur(Joueur j);
  void regleDuJeux(Joueur *j,  Carte c);
  Carte carteCourante();
  void supprimer(Carte  c);
  int getSens() const;
  void modifierSens();
  void modifierJoueurCourant();
  void supprimerCarteJoueur(Joueur* j,Carte c);
  int getJoueurCourant() const;
  Carte getCarteCourante() const;
  void modifierCarteCourante(Carte c);
  Carte getCarte(int indice);
  void historique(Carte c);
  void remplirPaquet();
};

#endif 
