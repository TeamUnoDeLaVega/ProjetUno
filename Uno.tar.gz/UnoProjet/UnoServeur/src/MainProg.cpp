#include <iostream>
#include <string>
#include "Carte.hpp"
#include "Joueur.hpp" 
#include "JeuSrv.hpp"

int main() {
  JeuSrv s(5550);
  s.initServer();
  s.run();
  
  return 0; 

} 

