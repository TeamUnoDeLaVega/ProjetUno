#include "Joueur.hpp"
#include <iostream>



Joueur::Joueur(int valeur, std::string nom):_id(valeur),_nom(nom){} // créer un Joueur 

void Joueur::setIdJoueur(int valeur){  // attribuer un id à un joueur 
  _id=valeur;
}

void Joueur::setNomJoueur(std::string nom){  //atribuer un nom à un joueur 
  _nom=nom;
}

int Joueur::getIdJoueur()const{
  return _id;
}

  std::string Joueur::getNom(){
	  return _nom;
 }


   
void Joueur::afficherJoueur()const{
  std::cout << "tableau du joueur " << std::endl;
  for(int i=0;i<(int)_cartesJoueur.size();i++){
    std::cout << _cartesJoueur[i].getValeur() << _cartesJoueur[i].getCouleur() << ";" ;
  }
  std::cout << " " << std::endl;
}



std::vector<Carte> Joueur::getCartesJoueur()const {  //obtenir le vecteur du joueur 
  return _cartesJoueur;
}

  
